<style type="text/css">
	div {
		width: 400px;		
		margin: 100px auto;
	}
	img {
		width: 100%;
	}
	h1 {
		text-align: center;
	}
</style>
<div>
	<h1>You're Special!!!!</h1>
	<img src="<?php bloginfo('template_directory'); ?>/images/rainbow-unicorn.jpg">
</div>